# Camera and decoded pack evidence, Java 26.3

Extract this archive into a private results directory. SHA256SUMS.txt covers every other archive member. Camera files contain the full local projection matrix, image digest and per-frame registered visible-corner errors. On the experiment branches, earlier methods change only their candidate source. The seam camera always receives first refusal.

## The 152 release frames

Follow training/DATASET.md to fetch the four assets from the Visible Builds v1 GitHub release (https://github.com/jeremyepling/minecraft-image-reconstruction/releases/tag/visible-builds-v1). Keep the ZIPs in DATA and unzip each under DATA/data/SPLIT so that DATA/data/SPLIT/frames/ID/rgb.png exists. The runner verifies each release ZIP and RGB digest before evaluating. Use the 26.3 calibrated texture assets identified by the camera evidence. The camera predictor receives only an RGB image and the game version; the block labels, world coordinates and recorded camera are scorer inputs. All three camera rounds use hand-coded methods without a learned model.

From the checkout containing the three texture_camera_* modules, run the following commands with the appropriate directories substituted. Python requires NumPy and Pillow. Wall evaluation also requires OpenCV. On the benchmark PC the wall runs used the mask-scalelsd worktree's runs/env/Scripts/python.exe.

    python -m benchmark.texture_camera_eval --data DATA --split all --out NEW/baseline
    python -m benchmark.texture_camera_eval --data DATA --baseline NEW/baseline --candidate-root FLOOR --candidate engine.camera_atlas_floor --split all --out NEW/floor
    python -m benchmark.texture_camera_placement --data DATA --camera NEW/floor --split all --out NEW/placement-floor
    python -m benchmark.texture_camera_placement --data DATA --camera NEW/baseline --split validation --recorded-camera --out NEW/recorded-validation

Use a checkout of experiment/camera-floor-texture at fb9d5b4 as FLOOR to reproduce the hardened atlas floor camera. Commit 1fedad9 holds the original frozen round-three variant. Use experiment/camera-wall-atlas at 2b942bb as the candidate root for benchmark.wall_atlas_guard or benchmark.wall_atlas_consensus. The placement runner can also consume the exact camera records in this ZIP directly, e.g. pass --camera camera/floor/r3-final --split test. Supply the original saved release ZIP/PNG files even when reusing camera predictions. Ground-relative integer gauge and compass are fixed by the common registration rule for scoring. The optional recorded-camera control injects the actual pose and should be reported separately from every image-only result.

Placement inputs are the frame-matched archived photo surface predictions in benchmark/reviews/edge-detail-stable-01 and benchmark/reviews/detail-transfer-01; the runner verifies their expected digests, refines held-suite masks, measures counts and decodes the emitted structure pack. A per-frame registered.json lists its scored world cells and the exact visible-set intersection. Each corresponding ZIP contains the local-grid Minecraft structure. Sum correct_visible, extra and missed for retrieval metrics. The diagnostic pack exporter uses smooth stone, so material scoring belongs in the joint_correct column. ZIP entry timestamps can change on regeneration. Compare decoded coordinates when replaying.

## The additional 70 native test frames

These are a different archived capture suite. native-inputs/index.json contains all 70 original PNG digests, saved baseline support statuses and paths relative to the fixture directory. The index contains every views.json entry marked test in each of the four directories: entrance-holdout-26.3/positive, entrance-holdout-26.3/controls, shape-benchmark-open-26.3 and shape-benchmark-26.3. Each original saved PNG lives at FIXTURES/<fixture_directory>/captures/<id>.png. The workspace on the benchmark PC has FIXTURES at C:/code/minecraft/workspace/builds. Reuse the original capture archives if rebuilding the tree elsewhere. Copy each matching RGB file to the same relative path. Preserve the supplied per-frame pose and server block readback there too; those JSON files and original views lists are included under native-inputs in this ZIP. The archived RGB files occupy 112 MB and are stored outside this score bundle.

To replay against the portable index, set FIXTURES to the root that contains those four original directories. Alternatively populate their captures directories in native-inputs with the verified original PNGs and pass native-inputs as FIXTURES. Prior benchmark/reviews/supported-placement-01/holdout.json documents the original screen. Evaluate using the fitted source from each method's own checkout.

    python -m benchmark.texture_camera_native --index native-inputs/index.json --fixtures FIXTURES --candidate-root FLOOR --candidate engine.camera_atlas_floor --out NEW/native-floor
    python -m benchmark.texture_camera_native --index native-inputs/index.json --fixtures FIXTURES --candidate-root WALL --candidate benchmark.wall_atlas_guard --out NEW/native-wall-guard
    python -m benchmark.texture_camera_native --index native-inputs/index.json --fixtures FIXTURES --candidate-root WALL --candidate benchmark.wall_atlas_consensus --out NEW/native-wall-broad

The native screen checks all 70 RGB hashes and that the release split has no matching RGB; it verifies the original camera support flag on every fresh prediction. Its scorer uses only faces supported by the source image. Each native case stores both original and proposed camera scores. Aggregate native corners and decoded placement represent different tasks.

