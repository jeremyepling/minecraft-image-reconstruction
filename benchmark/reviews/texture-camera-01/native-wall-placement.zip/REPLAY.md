# Native wall camera placement

Use the native input RGBs, recorded poses and block readbacks described in the adjacent scoring.zip.
Each selected broad-wall view had an abstention from the promoted floor camera.
Every surface input here came from one ordinary Invoke-WallRecovery.ps1 -Through counts run on its RGB.
To regenerate a surface run, send its original PNG through that wrapper and set -Out to surfaces/FRAME_ID.

Extract this bundle and run the following command from the repository using Python, Pillow and NumPy.
Set FIXTURES to the native fixture root and SURFACES to this bundle's extracted surfaces directory.

    python -m benchmark.texture_camera_native_placement --fixtures FIXTURES --surfaces SURFACES --out NEW

The same image-derived masks and counts are shared across both wall methods and the recorded-camera diagnostic.
The scorer registers decoded local cube centers and compares exact world coordinates and exported block IDs
against native pixel-visible building truth. Floor, occluded and off-image cells cannot earn a match.
The guard-supported summary covers the exact three images on which the guard returned a camera.
