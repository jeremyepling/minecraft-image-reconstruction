place template reconstruction:part_0 ~-4 ~-1 ~-2
place template reconstruction:part_1 ~-4 ~-1 ~0
place template reconstruction:part_2 ~-4 ~0 ~-1
place template reconstruction:part_3 ~0 ~-1 ~-1
place template reconstruction:part_4 ~0 ~0 ~-1
