"""Extend the scale-support screen to all 70 native test views and 96 released pilot views."""
from evaluate import OUT, DATA, EXTRA, checked, Image, read, revision, save, Path, digest
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from engine.camera_seam import predict
from training.visible_labels import visible_labels

def check(job):
    cohort,row=job
    key=row['id']
    folder=(Path(row['root'])/'captures') if cohort=='native70' else DATA/'data'/row['split']/'frames'/key
    rgb=folder/(key+'.png' if cohort=='native70' else 'rgb.png')
    with Image.open(checked(rgb,row['sha256'])) as src:
        cam=predict(src.convert('RGB'),'26.3')
    assert bool(cam['P'] is not None)==row['supported']
    assert cam['scale_status']==row['status']
    if cohort=='native70':
        pose=read(folder/(key+'.json'))
        actual={tuple(b[k] for k in 'xyz'):b for b in read(folder/(key+'-blocks.json'))}
        staged={tuple(b[k] for k in 'xyz'):b for b in read(Path(row['root'])/'layout.json')['blocks'] if b['page']==row['page']}
        assert staged.keys()==actual.keys() and all(staged[k]['block_id']==v['block_id'] for k,v in actual.items())
        states={k:v for k,v in actual.items() if staged[k].get('role')!='floor_probe'}
        labels=visible_labels(pose,states,(0,0,0))[0]
    else:
        meta=read(folder/'frame.json')
        labels=read(checked(folder/'labels.json',meta['files']['labels.json']))
    return dict(cohort=cohort,key=key,split=row.get('split','test'),camera=cam['scale_status'],rgb_sha256=row['sha256'],
                visible=len(labels['blocks']),supported=cam['P'] is not None)

if __name__=='__main__':
    jobs=[(c,row) for c,p in (('native70','other-cameras.json'),('pilot96','pilot-camera.json')) for row in read(EXTRA/p)]
    with ProcessPoolExecutor(4) as pool:
        rows=list(pool.map(check,jobs))
    stats={}
    for c in ('native70','pilot96'):
        rs=[r for r in rows if r['cohort']==c]
        stats[c]=dict(frames=len(rs),supported=sum(r['supported'] for r in rs),visible=sum(r['visible'] for r in rs),
                      supported_visible=sum(r['visible'] for r in rs if r['supported']))
    save(OUT/'camera-screen.json',dict(revision=revision(),stats=stats,cases=rows))
    print(stats)
