"""Camera quality on references and nearest-target distances for unsupported exports."""
from evaluate import (OUT, ROOT, read, save, frame_jobs, checked, np, Image, Counter,
                      ProcessPoolExecutor, mark_image_only)
from benchmark.camera_metrics import score
from engine.camera_seam import predict

def diagnostics(job):
    key,group,layout,split,folder,meta,*_=job
    record=read(OUT/'frames'/key/'registered.json')
    target=np.array([v[:3] for v in record['visible_states']],dtype=int)
    good=set(map(tuple,record['correct']))
    extra=[p for p in record['registered'] if tuple(p) not in good]
    near=Counter()
    for p in extra:
        diff=np.abs(target-p)
        nearest=diff.sum(1).min()
        near[int(nearest)]+=1
    camera=None
    if group!='supported12':
        path=checked(folder/'rgb.png',meta['files']['rgb.png'])
        with Image.open(path) as photo: pred=predict(photo,'26.3')
        # The estimator exposes a metric projection only; plane proposals are not camera estimates.
        pose=read(checked(folder/'camera.json',meta['files']['camera.json']))
        faces=read(checked(folder/'reference-faces.json',meta['files']['reference-faces.json']))['faces']
        camera=score(dict(pred,planes=[]),pose,faces)
        camera['reason']=pred['reason']
    return dict(key=key,group=group,camera=camera,manhattan_distance_from_extra_to_nearest_visible_block=near)

if __name__=='__main__':
    with ProcessPoolExecutor(4,initializer=mark_image_only) as pool:
        rows=list(pool.map(diagnostics,frame_jobs()))
    stats={}
    for group in ('fixed56','additional24','supported12'):
        rs=[r for r in rows if r['group']==group]
        cs=[r['camera'] for r in rs if r['camera']]
        n=sum(c['projected'] for c in cs)
        stats[group]=dict(extra_nearest=dict(sum((Counter(r['manhattan_distance_from_extra_to_nearest_visible_block']) for r in rs),Counter())),
                          visible_vertices=sum(c['vertices'] for c in cs),projected=n,
                          projected_within_two_pixels=sum(c['within_2px'] for c in cs),
                          projected_vertex_mean_error_px=sum(c['projected']*(c['mean_px'] or 0) for c in cs)/n if n else None,
                          reasons=Counter(c['reason'] for c in cs), per_image_fov_error_deg=[c['fov_error_deg'] for c in cs if c['fov_error_deg'] is not None])
    save(OUT/'diagnostics.json',dict(stats=stats,rows=rows))
    print(stats)
