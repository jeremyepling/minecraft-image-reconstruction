"""Frozen geometry-to-material wiring diagnostic. Predict all packs before opening scoring labels."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MCIR_IMAGE_ONLY='1')
from pathlib import Path
import sys
OUT=Path(__file__).resolve().parent
GEOM=OUT.parent
sys.path.insert(0,str(GEOM))
from evaluate import (ROOT, BUILD, DATA, FREEZE, EXTRA, read, save, checked, read_gzip, Image,
                      np, Counter, decoded_pack, registration, digest, revision, ProcessPoolExecutor)
from engine.camera_seam import predict as seam_camera
from engine.visible_placement import FACE_CORNERS
from engine.visible_raster import rasterize
from engine.surface_perimeter import _native_alpha
from engine.face_evidence import effective_width, MIN_FACE_WIDTH
from engine.surface_model import _material_assets
from engine.export import write_pack, JAVA_26_3_FORMAT
PLACEHOLDER='minecraft:smooth_stone'
ASSETS=ROOT.parent/'workspace/builds/mcir-port-validation/final-cli-26.3/atlas'
RULE=dict(camera='seam camera from RGB', proposed_geometry='decoded geometry-only local placements',
          visibility='all rasterized native pixel centers frontmost for the exact face and inside one predicted surface; all four vertices on-screen',
          min_effective_width_native_pixels=MIN_FACE_WIDTH, face_selection='widest then largest area then lowest enumeration index',
          matcher='shape (unchanged)', abstaindecision='existing matcher ambiguous flag: top-two margin below .04 or a texture with multiple IDs',
          default='preserve smooth_stone on no complete visible face or ambiguous match')

def init():
    global MATCHER
    atlas,MATCHER,_,failures=_material_assets('26.3','texture-guided-repeat','shape',ASSETS)
    assert MATCHER and not failures

def input_jobs():
    freeze=read(FREEZE/'manifest.json')
    native={r['id']:Path(r['root'])/'captures' for r in read(EXTRA/'other-cameras.json')}
    jobs=[]
    for key,v in freeze.items():
        group='fixed56' if '/' in key else 'supported12'
        pack=GEOM/'frames'/key/'reconstruction.zip'
        if not decoded_pack(pack): continue
        image=(DATA/'data/regression/frames'/('legacy-'+key.replace('/','-'))/'rgb.png') if group=='fixed56' else native[key]/(key+'.png')
        jobs.append((key,group,image,v['rgb'],v['masks'],pack))
    assert Counter(j[1] for j in jobs)==dict(fixed56=16,supported12=12)
    return jobs

def projected_faces(coords,p,size):
    w,h=size
    owner=np.full((h,w),-1,np.int32)
    depths=np.zeros((h,w))
    eye=np.linalg.solve(p[:,:3],-p[:,3])
    records=[]
    for cell in sorted(coords):
        for axis in range(3):
            if cell[axis]<=eye[axis]<=cell[axis]+1: continue
            sign=1 if eye[axis]>cell[axis] else -1
            neighbor=list(cell); neighbor[axis]+=sign
            if tuple(neighbor) in coords: continue
            corners=np.tile(cell,(4,1))
            corners[:,axis]+=int(sign>0)
            corners[:,[i for i in range(3) if i!=axis]]+=FACE_CORNERS
            proj=corners@p[:,:3].T+p[:,3]
            if proj[:,2].min()<=1.e-5: continue
            hit=rasterize(proj,w,h)
            if hit is None: continue
            roi,mask,depth,area,quad=hit
            closer=mask&(depth>depths[roi])
            owner[roi][closer]=len(records)
            depths[roi][closer]=depth[closer]
            records.append((cell,axis,sign,roi,mask,area,quad))
    return records,owner

def predict(job):
    key,group,rgb,im_hash,mask_hash,pack=job
    with Image.open(checked(rgb,im_hash)) as photo:
        photo=photo.convert('RGB')
    parts=read_gzip(checked(FREEZE/(key+'.json.gz'),mask_hash))
    blocks=decoded_pack(pack)
    assert set(blocks.values())=={PLACEHOLDER}
    camera=seam_camera(photo,'26.3')
    assert camera['P'] is not None
    projection=np.array(camera['P'])
    masks=[]
    for part in parts:
        alpha=_native_alpha(part['support'],photo.size)
        if alpha:
            tile,box=alpha
            masks.append((box,np.asarray(tile)>0,part['id']))
    seen={}
    records,owner=projected_faces(blocks,projection,photo.size)
    for i,(cell,axis,sign,roi,mask,area,quad) in enumerate(records):
        if (quad<0).any() or (quad>photo.size).any(): continue
        width=effective_width(quad)
        if width<MIN_FACE_WIDTH or not np.all(owner[roi][mask]==i): continue
        ys,xs=np.nonzero(mask)
        xs+=roi[1].start; ys+=roi[0].start
        bounds=xs.min(),ys.min(),xs.max(),ys.max()
        for (x0,y0,x1,y1),support,pid in masks:
            if bounds[0]<x0 or bounds[1]<y0 or bounds[2]>=x1 or bounds[3]>=y1: continue
            if support[ys-y0,xs-x0].all(): break
        else: continue
        rank=(width,area,-i)
        if cell not in seen or rank>seen[cell][0]: seen[cell]=rank,quad,pid,axis,sign
    array=np.asarray(photo)
    logs=[]
    for cell,((width,_,_),quad,pid,axis,sign) in sorted(seen.items()):
        result=MATCHER.rank(array,quad)
        block='minecraft:'+result['block_id']
        if not result['ambiguous']: blocks[cell]=block
        logs.append(dict(cell=cell,predicted_id=block,accepted=not result['ambiguous'],quad=quad.tolist(),surface_id=pid,
                         axis=axis,sign=sign,width_px=width,score_margin=result['score_margin']))
    dest=OUT/'frames'/key
    dest.mkdir(parents=True,exist_ok=True)
    write_pack(dest/'projection.zip',{c:b.removeprefix('minecraft:') for c,b in blocks.items()},JAVA_26_3_FORMAT)
    assert decoded_pack(dest/'projection.zip')==blocks
    save(dest/'predicted.json',dict(key=key,group=group,input_rgb_sha256=im_hash,mask_sha256=mask_hash,
                                    baseline_pack_sha256=digest(pack),projection=projection.tolist(),choices=logs))
    return key

def score(job):
    key,group,rgb,*_=job
    dest=OUT/'frames'/key
    guess=read(dest/'predicted.json')
    base=decoded_pack(job[-1]); predicted=decoded_pack(dest/'projection.zip')
    assert base.keys()==predicted.keys()
    states={tuple(v[:3]):v[3] for v in read(GEOM/'frames'/key/'registered.json')['visible_states']}
    pose=read(rgb.with_name('camera.json' if group=='fixed56' else key+'.json'))
    transform=registration(np.asarray(guess['projection']),pose)
    given={tuple(r['cell']):r for r in guess['choices']}
    counts=Counter(frames=1,target=len(states),placed=len(predicted),eligible=len(given))
    for pos,material in predicted.items():
        world=tuple(np.floor(transform[:3,:3]@(np.array(pos)+.5)+transform[:3,3]).astype(int))
        target=states.get(world); choice=given.get(pos)
        ok=target==material; old=target==base[pos]
        counts.update(baseline_correct=int(old),correct=int(ok),gained=int(ok and not old),lost=int(old and not ok),
                      aligned=int(target is not None),wrong_id=int(target is not None and not ok),extra=int(target is None))
        if choice:
            counts['accepted' if choice['accepted'] else 'ambiguous']+=1
            if choice['accepted']:
                counts.update(accepted_correct=int(ok),accepted_wrong_id=int(target is not None and not ok),
                              accepted_at_extra=int(target is None))
            else:
                counts['ambiguous_exact_top1_if_forced']+=int(target==choice['predicted_id'])
    return dict(key=key,group=group,counts=dict(counts))

if __name__=='__main__':
    jobs=input_jobs()
    with ProcessPoolExecutor(6,initializer=init) as pool:
        keys=list(pool.map(predict,jobs))
    assert len(keys)==28
    rows=list(map(score,jobs))
    stats={group:dict(sum((Counter(r['counts']) for r in rows if r['group']==group),Counter())) for group in ['fixed56','supported12']}
    save(OUT/'results.json',dict(code=revision(),rule=RULE,groups=stats,rows=rows,
                                atlas_sha256=digest(ASSETS/'atlas.png'),runner_sha256=digest(Path(__file__))))
    print(stats)
