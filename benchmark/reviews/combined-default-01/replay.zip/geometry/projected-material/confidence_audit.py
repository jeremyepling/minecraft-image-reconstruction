"""Score the unchanged matcher's existing ambiguity flag after all predictions have been frozen."""
from test_projected import OUT, GEOM, input_jobs, read, save, registration, np, Counter, PLACEHOLDER

if __name__=='__main__':
    totals={}
    for key,cohort,rgb,*_ in input_jobs():
        pred=read(OUT/'frames'/key/'predicted.json')
        truth={tuple(r[:3]):r[3] for r in read(GEOM/'frames'/key/'registered.json')['visible_states']}
        pose=read(rgb.with_name('camera.json' if cohort=='fixed56' else key+'.json'))
        t=registration(np.asarray(pred['projection']),pose)
        groups=[cohort]
        if cohort=='fixed56': groups += ['dev' if '/dev-' in key else 'regression']
        for row in pred['choices']:
            xyz=tuple(np.floor(t[:3,:3]@(np.array(row['cell'])+.5)+t[:3,3]).astype(int))
            target=truth.get(xyz)
            for group in groups:
                metric=totals.setdefault(group,{}).setdefault('accepted' if row['accepted'] else 'ambiguous',Counter())
                correct=target==row['predicted_id']; old=target==PLACEHOLDER
                metric.update(attempts=1,at_correct_xyz=int(target is not None),at_extra=int(target is None),
                              exact_if_used=int(correct),wrong_id_aligned=int(target is not None and not correct),
                              exact_gained_if_used=int(correct and not old),exact_lost_if_used=int(old and not correct))
    save(OUT/'confidence-audit.json',totals)
    print(totals)
