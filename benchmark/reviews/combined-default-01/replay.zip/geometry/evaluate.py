"""Replay the released screenshots against the November 26 production geometry pipeline."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MCIR_IMAGE_ONLY='1')
import sys
from pathlib import Path
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import json
from zipfile import ZipFile
from PIL import Image
import numpy as np
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sys.path.insert(0, str(ROOT))
from benchmark.camera_round import digest, read, save, revision
from benchmark.camera_metrics import registration
from benchmark.mask_blocks import _score, _write_read, decoded_pack, registered
from benchmark.mask_metrics import measure, aggregate
from benchmark.surface_metrics import truth
from benchmark.count_metrics import reference_planes
from benchmark.texture_count_round import FINDERS
from benchmark.wall_join_test import checked, read_gzip
from benchmark.detail_transfer import ARCHIVE, shards
from benchmark.surface_reference import ARCHIVE as VISIBLE_ARCHIVE
from training.visible_labels import visible_labels
from engine.surface_model import _count_regions, DEFAULTS
from engine.photo_edges import refine_surfaces
from engine.visible_placement import place
from runtime.mode import mark_image_only

DATA = ROOT/'runs/visible-builds-v1'
REF = ROOT/'benchmark/reviews'
BUILD = ROOT.parent/'workspace/builds'
EXTRA = BUILD/'supported-placement-holdout'
FREEZE = BUILD/'seam-review/promoted-inputs'
BEFORE = BUILD/'seam-review/promoted-combined/packs'
CURRENT_FINDER, METHOD = FINDERS['photo']

def frame_jobs():
    rel = read(ROOT/'training/visible-builds-v1.json')
    rows = {}
    for split in ['regression','validation','test']:
        shard = rel['shards'][split]
        with ZipFile(checked(DATA/shard['file'],shard['sha256'])) as z:
            for line in z.read('frames.jsonl').splitlines():
                frame = json.loads(line)
                rows[frame['id']] = (DATA/'data'/split/frame['directory'],frame)
    mf = read(CURRENT_FINDER/'manifest.json')
    checked(VISIBLE_ARCHIVE, mf['reference_sha256'])
    jobs=[]
    for row in read(checked(CURRENT_FINDER/'cases.json',mf['artifacts']['cases.json'])):
        key=row['key']
        folder, f=rows['legacy-'+key.replace('/','-')]
        assert row['sha256']==f['files']['rgb.png']
        p=row['predictions']
        jobs.append((key,'fixed56',row['layout'],row['cohort'],folder, f, CURRENT_FINDER/p, mf['artifacts'][p], row['scores'][METHOD]))
    mf=read(ARCHIVE/'manifest.json')
    for k,(folder,f) in rows.items():
        if f['split'] not in ('validation','test'): continue
        p='ordinary/'+k+'.json.gz'
        jobs.append((k,'additional24',f['family'],f['split'],folder,f,ARCHIVE/p,mf['artifacts'][p],None))
    frozen=read(FREEZE/'manifest.json')
    for row in read(EXTRA/'results.json')['results']:
        k=row['id']
        assert frozen[k]['rgb']==row['rgb_sha256'] and frozen[k]['source']==row['surface_sha256']
        jobs.append((k,'supported12',k.rsplit('-',1)[0],'camera-selected',Path(row['root'])/'captures',row,
                     FREEZE/(k+'.json.gz'),frozen[k]['masks'],None))
    assert Counter(j[1] for j in jobs)=={'fixed56':56,'additional24':24,'supported12':12}
    return jobs

def evaluate(job):
    key,group,layout,split,folder,meta,mask_path,hash_masks,expected_masks=job
    external=group=='supported12'
    path=folder/(key+'.png' if external else 'rgb.png')
    sha=meta['rgb_sha256'] if external else meta['files']['rgb.png']
    with Image.open(checked(path,sha)) as opened:
        photo=opened.convert('RGB')
    data=read_gzip(checked(mask_path,hash_masks))
    if external:
        parts=data
    elif group=='fixed56':
        parts=data[METHOD]
    else:
        assert data['manifest']['image_sha256']==sha
        parts,_=refine_surfaces(photo,data['planes'])
    out=OUT/'frames'/key
    out.mkdir(exist_ok=True,parents=True)
    counts=_count_regions(photo,parts,'26.3',read(DEFAULTS)['block_count'],None,out)
    cells,status=place(photo,'26.3',parts,counts=counts)
    pack=out/'reconstruction.zip'
    local=_write_read(pack,cells)
    # Scoring only below. Every exported block state was independently verified by _write_read.
    def release(name):
        return read(checked(folder/name,meta['files'][name]))
    if not external:
        pose=release('camera.json')
        labels=release('labels.json')
        faces=release('reference-faces.json')['faces']
        ref=truth(pose,faces)
        masks,pairs=measure(parts,ref,use_mask=True)
        if expected_masks is not None:
            for k,v in expected_masks.items():
                assert np.allclose(v,masks[k]),(k,v,masks[k],key)
        real=reference_planes(ref,faces)
        matched={i:rid for i,rid in pairs}
        sizes=Counter(correct=0,wrong=0,matched_incomplete=0,unmatched_complete=0,unmatched_incomplete=0)
        for i,r in enumerate(counts['surfaces']):
            d=r['dimensions']['blocks']
            if i not in matched:
                sizes['unmatched_incomplete' if None in d else 'unmatched_complete']+=1
            elif d==real[matched[i]]['size']:
                sizes['correct']+=1
            else:
                sizes['matched_incomplete' if None in d else 'wrong']+=1
        sizes['missing']=masks['eligible']-sizes['correct']-sizes['wrong']
    else:
        pose=read(checked(folder/(key+'.json'),meta['pose_sha256']))
        world_readback=read(checked(folder/(key+'-blocks.json'),meta['states_sha256']))
        states={tuple(b[k] for k in 'xyz'):b for b in world_readback}
        labels,_,_=visible_labels(pose,states,(0,0,0))
        assert len(labels['blocks'])==meta['visible']
        masks=sizes=None
    target={tuple(b['xyz_world']):b['block_id'] for b in labels['blocks']}
    smooth={p for p,b in target.items() if b=='minecraft:smooth_stone'}
    world=registered(local,registration(np.asarray(status['P']),pose)) if local else set()
    scores=_score(world,set(target))
    save(out/'registered.json',dict(key=key,registered=sorted(world),correct=sorted(world & target.keys()),
                                   visible_states=[[*p,b] for p,b in sorted(target.items())]))
    scores.update(smooth_truth=len(smooth),joint_correct=len(smooth&world))
    delta={}
    if group!='additional24':
        prior=set(decoded_pack(BEFORE/(key+'.zip')))
        assert not prior or status['P'] is not None
        old=registered(prior,registration(np.asarray(status['P']),pose)) if prior else set()
        hits=set(target)
        delta=dict(correct_gain=len((world-old)&hits),correct_loss=len((old-world)&hits),extra_added=len(world-old-hits),
                   extra_removed=len(old-world-hits))
    del status['P']
    result=dict(key=key,group=group,layout=layout,split=split,image_sha256=sha,masks_sha256=hash_masks,
                camera=status,placement=scores,delta_vs_old_counter=delta,surfaces=masks,sizes=sizes)
    save(out/'scores.json',result)
    return result

def summarize(rows):
    coord=sum((Counter(r['placement']) for r in rows),Counter())
    for key in ('serialized','visible_truth','correct_visible','extra','missed','joint_correct','smooth_truth'):
        coord.setdefault(key,0)
    masks=[r['surfaces'] for r in rows if r['surfaces']]
    return dict(frames=len(rows), cameras=Counter(r['camera']['camera_status'] for r in rows), placements=dict(coord),
                old_counter_delta={k:sum(r['delta_vs_old_counter'].get(k,0) for r in rows) for k in ('correct_gain','correct_loss','extra_added','extra_removed')} if rows[0]['delta_vs_old_counter'] else None,
                precision=coord['correct_visible']/coord['serialized'] if coord['serialized'] else None,
                recall=coord['correct_visible']/coord['visible_truth'],produced=sum(bool(r['placement']['serialized']) for r in rows),
                camera_supported_truth=sum(r['placement']['visible_truth'] for r in rows if r['camera']['camera_status']=='supported'),
                supported_wrong=sum(r['placement']['extra'] for r in rows if r['camera']['camera_status']=='supported'),
                surfaces=aggregate(masks) if masks else None,sizes=dict(sum((Counter(r['sizes']) for r in rows if r['sizes']),Counter())))

if __name__=='__main__':
    jobs=frame_jobs()
    with ProcessPoolExecutor(max_workers=6,initializer=mark_image_only) as pool:
        rows=list(pool.map(evaluate,jobs))
    groups={k:summarize([r for r in rows if r['group']==k]) for k in dict.fromkeys(r['group'] for r in rows)}
    by_layout={k:summarize([r for r in rows if r['layout']==k]) for k in dict.fromkeys(r['layout'] for r in rows)}
    by_split={k:summarize([r for r in rows if r['split']==k]) for k in dict.fromkeys(r['split'] for r in rows)}
    contexts=[CURRENT_FINDER/'manifest.json',ARCHIVE/'manifest.json',VISIBLE_ARCHIVE,FREEZE/'manifest.json',
              EXTRA/'results.json',BEFORE.parent/'results.json',ROOT/'training/visible-builds-v1.json']
    save(OUT/'results.json',dict(revision=revision(),settings=read(DEFAULTS),fixture_digests={str(p):digest(p) for p in contexts},
                                 groups=groups,layouts=by_layout,splits=by_split,cases=rows))
    for k,v in groups.items(): print(k,v['placements'],v['cameras'],v['sizes'])
