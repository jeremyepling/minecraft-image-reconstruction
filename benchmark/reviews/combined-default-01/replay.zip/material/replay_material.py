"""Score current local material extraction and its perfect top-five chooser ceiling on 80 frames."""
import hashlib
import io
import json
import subprocess
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
OLD=ROOT.parent/'minecraft-image-reconstruction-worktrees/atlas-phase-materials'
sys.path.insert(0,str(ROOT))
import benchmark
benchmark.__path__.append(str(OLD/'benchmark'))
from benchmark.camera_round import digest, read, save
from benchmark.count_materials import true_faces
from benchmark.count_metrics import reference_planes
from benchmark.detail_transfer import ARCHIVE as FAMILIES, member, shards
from benchmark.mask_metrics import measure
from benchmark.normal_round import groups
from benchmark.phase_material_round import grade, link
from benchmark.surface_metrics import truth
from benchmark.surface_reference import ARCHIVE, recorded
from benchmark.wall_join_test import checked, read_gzip
from engine.face_evidence import effective_width, MIN_FACE_WIDTH
from engine.photo_edges import refine_surfaces
from engine.surface_model import DEFAULTS, _material_assets, _count_regions, canonical
from engine.surface_tiles import tile_sample
from runtime.mode import mark_image_only

SOURCE=ROOT/'benchmark/reviews/edge-detail-stable-01'
SETTINGS=read(DEFAULTS)
DATA=ROOT/'runs/visible-builds-v1'
FIXMAN='d8a2c401d28c546762bcef38ed731c4074120f3750f2998a5b7e797fcb6e9a43'

def init():
    global atlas,matcher
    mark_image_only()
    atlas,matcher,_,_=_material_assets('26.3',SETTINGS['block_count'],'shape',None)
    assert atlas and matcher

def one(job):
    cap,frame,source,key,sha,pred,cohort,layout=job
    if cap:
        with Image.open(checked(cap.path('image'),sha)) as f:
            image=f.convert('RGB')
        parts=read_gzip(checked(SOURCE/source,pred))['edge_detail:native4-stable-counts']
    else:
        with ZipFile(source) as z:
            rgb=member(z,frame,'rgb.png')
            assert hashlib.sha256(rgb).hexdigest()==sha
            image=Image.open(io.BytesIO(rgb)).convert('RGB')
        archived=read_gzip(checked(FAMILIES/'ordinary'/(key+'.json.gz'),pred))
        assert archived['manifest']['image_sha256']==sha
        parts,_=refine_surfaces(image,archived['planes'])
    with TemporaryDirectory(dir=OUT) as d:
        report=_count_regions(image,parts,'26.3',SETTINGS['block_count'],atlas,Path(d),matcher)
    predrows=[]
    for part in report['surfaces']:
        for face in part.get('visible_cells',[])+part.get('under_five_px_faces',[]):
            predrows.append(dict(face,proposal=part['id'],block_id=(face.get('material') or {}).get('block_id')))
    predrows.sort(key=lambda r:r['face_index'])
    if cap:
        ref=recorded(cap)[1]
        faces=read(cap.path('labels'))['faces']
    else:
        with ZipFile(source) as z:
            faces=json.loads(member(z,frame,'reference-faces.json'))['faces']
            pose=json.loads(member(z,frame,'camera.json'))
        ref=truth(pose,faces)
    valid=true_faces(reference_planes(ref,faces),image.size)
    paired={parts[i]['id']:rid for i,rid in measure(parts,ref,use_mask=True)[1]}
    score,records=grade(predrows,link(predrows,paired,valid,ref),valid)
    score['aligned_top5']=0
    for r,p in zip(records,predrows,strict=True):
        sourceface=p['material_source_face']
        mat=(predrows[sourceface].get('material') or {}) if sourceface is not None else {}
        r['ranked_ids']=mat.get('ranked_ids',[])
        score['aligned_top5']+=int(r.get('aligned',False) and r['expected'] in r['ranked_ids'])
    diagnostic=Counter(sampled=0,attempted=0,top1=0,top5=0)
    examples=[]
    def order(k):
        f=valid[k]
        return hashlib.sha256(str((sha,f['xyz'],f['direction'])).encode()).digest()
    for k in sorted(valid,key=order)[:8]:
        f=valid[k]
        target='minecraft:'+f['block_id'].removeprefix('minecraft:')
        q=canonical(f['image_corners'])
        diagnostic['sampled']+=1
        if effective_width(q)<MIN_FACE_WIDTH:
            ids=[]
        else:
            answer=matcher.rank_patch(tile_sample(image,q)['rgb'])
            ids=['minecraft:'+b for b in answer['ranked_ids']]
            diagnostic['attempted']+=1
        diagnostic['top1']+=int(ids[:1]==[target]); diagnostic['top5']+=int(target in ids)
        examples.append(dict(xyz=f['xyz'],direction=f['direction'],expected=target,ranked_ids=ids))
    return dict(key=key,sha256=sha,cohort=cohort,layout=layout,source_predictions_sha256=pred,
                parts=len(parts),surfaces_both_counts=sum(None not in p['counts'] for p in report['surfaces']),
                surfaces_both_offsets=sum(None not in p['phase'] for p in report['surfaces']),
                surfaces_with_whole_cells=sum(bool(p.get('visible_cells') or p.get('under_five_px_faces')) for p in report['surfaces']),
                source_phase=report['atlas_phase'],score=score,known_corners=diagnostic,known_corners_audit=examples,faces=records)

def main():
    git=lambda p:subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()
    assert git(ROOT).startswith('7c2137c') and git(OLD).startswith('1014df5')
    fixture=read(checked(SOURCE/'manifest.json',FIXMAN))
    checked(ARCHIVE,fixture['reference_sha256'])
    groups_,_,hashes=groups()
    assert hashes==fixture['fixtures']
    caps={c.floor+'/'+c.id:(c,'development' if g=='development' else 'regression') for g,cc in groups_.items() for c in cc}
    jobs=[]
    for row in read(checked(SOURCE/'cases.json',fixture['artifacts']['cases.json'])):
        c,cohort=caps[row['key']]
        jobs.append((c,None,row['predictions'],row['key'],row['sha256'],fixture['artifacts'][row['predictions']],cohort,row['layout']))
    transfer=read(FAMILIES/'manifest.json')
    ds={}
    for split,path,sd in shards(DATA):
        ds[split]=sd['sha256']
        with ZipFile(path) as z:
            for line in z.read('frames.jsonl').splitlines():
                f=json.loads(line)
                assert f['split']==split
                key=f['id']; sha=f['image_sha256']; p=transfer['artifacts']['ordinary/'+key+'.json.gz']
                jobs.append((None,f,path,key,sha,p,f['family'],f['layout']))
    assert len(jobs)==len({j[3] for j in jobs})==80
    (OUT/'cases').mkdir(exist_ok=True)
    with ProcessPoolExecutor(max_workers=6,initializer=init) as pool:
        rows=[]
        for i,r in enumerate(pool.map(one,jobs)):
            rows.append(r)
            save(OUT/'cases'/(r['key'].replace('/','--')+'.json'),r)
            if (i+1)%10==0: print(i+1,flush=True)
    aggregate={}
    cohorts=set(r['cohort'] for r in rows)
    for scope in sorted(cohorts|{'all','fixed56','families24'}):
        ss=[r for r in rows if scope=='all' or scope==r['cohort'] or scope==('fixed56' if r['cohort'] in ('regression','development') else 'families24')]
        def total(field):
            v=Counter()
            for r in ss: v.update(r[field])
            return dict(v)
        aggregate[scope]=dict(frames=len(ss),unique_images=len({r['sha256'] for r in ss}),frames_with_exact=sum(r['score']['correct']>0 for r in ss),scores=total('score'),known_corners=total('known_corners'),flow={k:sum(r[k] for r in ss) for k in ('parts','surfaces_both_counts','surfaces_both_offsets','surfaces_with_whole_cells')},offsets_added=sum(r['source_phase']['offsets_added'] for r in ss))
    init()
    save(OUT/'scores.json',aggregate)
    save(OUT/'manifest.json',dict(revision=git(ROOT),scorer_revision=git(OLD),script_sha256=digest(Path(__file__)),fixed_geometry=digest(ARCHIVE),fixed_manifest=FIXMAN,fixtures=hashes,transfer_manifest=digest(FAMILIES/'manifest.json'),dataset_shards=ds,version='26.3',condition='vanilla clear noon',counter=SETTINGS['block_count'],material_match='shape',atlas=atlas.provenance,scoring='Exact visible face: eligible fully visible projected face with all corners observed and 4px minimum edge, one-to-one association on matched surface at IoU >= 0.5, max corner error <= 0.25 block, exact top ID. Known-corner diagnostic ranks 8 label-independent hash-picked eligible faces per frame, 5px effective source width gate.',frames=[dict(key=r['key'],sha256=r['sha256'],cohort=r['cohort'],source_artifact_sha256=r['source_predictions_sha256'],case_sha256=digest(OUT/'cases'/(r['key'].replace('/','--')+'.json'))) for r in rows],scores_sha256=digest(OUT/'scores.json')))
    print(json.dumps(aggregate,indent=2),flush=True)

if __name__=='__main__': main()

