"""Diagnostic only: true corners for reference-visible faces on already correct output block coordinates."""
from collections import Counter,defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from zipfile import ZipFile
import io,json,sys
from PIL import Image
import replay_material as m
from native12 import SOURCES
from benchmark.camera_labels import face_labels
OUT=m.OUT
GEOM=OUT.parent/'geometry/frames'
def work(job):
    scope,key,sha,kind,data,meta=job
    reg=m.read(GEOM/key/'registered.json'); correct=set(map(tuple,reg['correct']))
    visible={tuple(row[:3]):row[3] for row in reg['visible_states']}
    if '--smooth-only' in sys.argv:
        correct = {p for p in correct if visible[p]=='minecraft:smooth_stone'}
    scores=Counter(correct_placement=len(correct),eligible_crop=0,top1=0,top5=0,placeholder_correct_before=sum(visible[p]=='minecraft:smooth_stone' for p in correct),baseline_smooth_inside_candidates=0,top1_smooth_retained=0,top5_smooth_retained=0)
    if not correct: return dict(key=key,scope=scope,scores=dict(scores))
    if kind=='native':
        folder=Path(data['root'])/'captures'
        with Image.open(m.checked(folder/(key+'.png'),sha)) as f: image=f.convert('RGB')
        pose=m.read(m.checked(folder/(key+'.json'),data['pose_sha256']))
        states={tuple(b[k] for k in 'xyz'):dict(b,block_id=b['block_id'].removeprefix('minecraft:')) for b in m.read(m.checked(folder/(key+'-blocks.json'),data['states_sha256']))}
        faces=face_labels(pose,states,{p:'building' for p in states}); ref=m.truth(pose,faces)
    elif kind=='cap':
        with Image.open(m.checked(data.path('image'),sha)) as f: image=f.convert('RGB')
        ref=m.recorded(data)[1]; faces=m.read(data.path('labels'))['faces']
    else:
        with ZipFile(data) as z:
            image=Image.open(io.BytesIO(m.member(z,meta,'rgb.png'))).convert('RGB')
            pose=json.loads(m.member(z,meta,'camera.json'))
            faces=json.loads(m.member(z,meta,'reference-faces.json'))['faces']
        ref=m.truth(pose,faces)
    choices=defaultdict(list)
    for face in m.true_faces(m.reference_planes(ref,faces),image.size).values():
        xyz=tuple(face['xyz'])
        if xyz not in correct: continue
        target='minecraft:'+face['block_id'].removeprefix('minecraft:')
        assert visible[xyz]==target
        q=m.canonical(face['image_corners']); width=m.effective_width(q)
        if width>=m.MIN_FACE_WIDTH: choices[xyz].append((width,face['direction'],q))
    scores['eligible_crop']=len(choices)
    for xyz,options in choices.items():
        q=max(options,key=lambda o:(o[0],o[1]))[2]
        target=visible[xyz]
        ranked=['minecraft:'+v for v in m.matcher.rank_patch(m.tile_sample(image,q)['rgb'])['ranked_ids']]
        scores['baseline_smooth_inside_candidates']+=int(target=='minecraft:smooth_stone')
        scores['top1']+=int(ranked[0]==target)
        scores['top5']+=int(target in ranked)
        if target=='minecraft:smooth_stone':
            scores['top1_smooth_retained']+=int(ranked[0]==target)
            scores['top5_smooth_retained']+=int(target in ranked)
    return dict(key=key,scope=scope,scores=dict(scores))

if __name__=='__main__':
    jobs=[]
    for group,caps in m.groups()[0].items():
        for cap in caps: jobs.append(('fixed56',cap.floor+'/'+cap.id,cap.frame['image_sha256'],'cap',cap,None))
    for split,path,sd in m.shards(m.DATA):
        with ZipFile(path) as z:
            for line in z.read('frames.jsonl').splitlines():
                frame=json.loads(line); jobs.append(('additional24',frame['id'],frame['image_sha256'],'family',path,frame))
    for r in m.read(SOURCES)['results']: jobs.append(('camera_selected12',r['id'],r['rgb_sha256'],'native',r,None))
    with ProcessPoolExecutor(max_workers=5,initializer=m.init) as ex: cases=list(ex.map(work,jobs))
    total=defaultdict(Counter)
    for r in cases:
        for g in ('all',r['scope']): total[g].update(r['scores'])
    dest='placed-smooth-reference-crops.json' if '--smooth-only' in sys.argv else 'placed-reference-crops.json'
    m.save(OUT/dest,dict(rule='Diagnostic. Select correctly placed world cells by known coordinates, get all ground-truth fully visible faces with minimum 4-pixel projected edge and 5-pixel effective width, choose the widest per cell without seeing its ID, rank its exact annotated corners. Uses target coordinates, true pose/corners/visibility. Tests material scoring and ideal crop availability conditional on an already correct cell only. No claim about estimated-camera crops.', scores=dict(total),cases=cases))
    print(dict(total))

