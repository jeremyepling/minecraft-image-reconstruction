"""Score the same material rules on the 12 preselected camera-supported screenshots."""
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
from collections import Counter
import replay_material as m
from PIL import Image
from benchmark.camera_labels import face_labels

SOURCES=m.ROOT.parent/'workspace/builds/supported-placement-holdout/results.json'
MASKS=m.ROOT.parent/'workspace/builds/seam-review/promoted-inputs'
OUT=m.OUT/'native12'

def one(args):
    r,pred=args
    key=r['id']; sha=r['rgb_sha256']; folder=Path(r['root'])/'captures'
    with Image.open(m.checked(folder/(key+'.png'),sha)) as src: image=src.convert('RGB')
    parts=m.read_gzip(m.checked(MASKS/(key+'.json.gz'),pred))
    with TemporaryDirectory(dir=OUT) as temp:
        report=m._count_regions(image,parts,'26.3',m.SETTINGS['block_count'],m.atlas,Path(temp),m.matcher)
    raw=sorted([dict(c,proposal=p['id'],block_id=(c.get('material') or {}).get('block_id')) for p in report['surfaces']
                for c in p.get('visible_cells',[])+p.get('under_five_px_faces',[])],key=lambda x:x['face_index'])
    # Prediction has finished before opening the native pose and block readback.
    pose=m.read(m.checked(folder/(key+'.json'),r['pose_sha256']))
    blocks=m.read(m.checked(folder/(key+'-blocks.json'),r['states_sha256']))
    states={tuple(b[k] for k in 'xyz'):dict(b,block_id=b['block_id'].removeprefix('minecraft:')) for b in blocks}
    faces=face_labels(pose,states,{p:'building' for p in states})
    assert len({tuple(f['xyz']) for f in faces})==r['visible']
    ref=m.truth(pose,faces); valid=m.true_faces(m.reference_planes(ref,faces),image.size)
    pairs={parts[i]['id']:rid for i,rid in m.measure(parts,ref,use_mask=True)[1]}
    scores,graded=m.grade(raw,m.link(raw,pairs,valid,ref),valid)
    scores['aligned_top5']=0
    for g,p in zip(graded,raw,strict=True):
        f=p['material_source_face']
        g['ranked_ids']=((raw[f].get('material') or {}).get('ranked_ids',[]) if f is not None else [])
        scores['aligned_top5']+=int(g.get('aligned',False) and g['expected'] in g['ranked_ids'])
    diagnostic=Counter(sampled=0,attempted=0,top1=0,top5=0)
    def order(k):
        f=valid[k]; return hashlib.sha256(str((sha,f['xyz'],f['direction'])).encode()).digest()
    for k in sorted(valid,key=order)[:8]:
        f=valid[k]; q=m.canonical(f['image_corners']); ids=[]
        if m.effective_width(q)>=m.MIN_FACE_WIDTH:
            diagnostic['attempted']+=1
            ids=['minecraft:'+v for v in m.matcher.rank_patch(m.tile_sample(image,q)['rgb'])['ranked_ids']]
        diagnostic['sampled']+=1; diagnostic['top1']+=int(ids[:1]==[f['block_id']]); diagnostic['top5']+=int(f['block_id'] in ids)
    return dict(key=key,sha256=sha,cohort='camera_selected12',parts=len(parts),surfaces_both_counts=sum(None not in p['counts'] for p in report['surfaces']),
                surfaces_both_offsets=sum(None not in p['phase'] for p in report['surfaces']),
                surfaces_with_whole_cells=sum(bool(p.get('visible_cells') or p.get('under_five_px_faces')) for p in report['surfaces']),
                score=scores,known_corners=diagnostic,source_phase=report['atlas_phase'],faces=graded,source_predictions_sha256=pred)

if __name__=='__main__':
    OUT.mkdir(exist_ok=True); (OUT/'cases').mkdir(exist_ok=True)
    mf=m.read(MASKS/'manifest.json')
    jobs=[]
    for r in m.read(SOURCES)['results']:
        k=r['id']; assert mf[k]['rgb']==r['rgb_sha256'] and mf[k]['source']==r['surface_sha256']
        jobs.append((r,mf[k]['masks']))
    with ProcessPoolExecutor(max_workers=5,initializer=m.init) as ex: rows=list(ex.map(one,jobs))
    for r in rows: m.save(OUT/'cases'/(r['key']+'.json'),r)
    def counts(k):
        c=Counter()
        for r in rows: c.update(r[k])
        return dict(c)
    result=dict(frames=len(rows),frames_with_exact=sum(r['score']['correct']>0 for r in rows),scores=counts('score'),known_corners=counts('known_corners'),
                flow={k:sum(r[k] for r in rows) for k in ('parts','surfaces_both_counts','surfaces_both_offsets','surfaces_with_whole_cells')})
    m.save(OUT/'scores.json',result)
    m.save(OUT/'manifest.json',dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=m.ROOT,text=True).strip(),
            prior_manifest_sha256=m.digest(m.OUT/'manifest.json'),sources_sha256=m.digest(SOURCES),mask_manifest_sha256=m.digest(MASKS/'manifest.json'),
            script_sha256=m.digest(Path(__file__)),scores_sha256=m.digest(OUT/'scores.json'),case_sha256={r['key']:m.digest(OUT/'cases'/(r['key']+'.json')) for r in rows}))
    print(result)

