"""Evaluator-only join of correctly named face blocks to registered exported coordinates."""
from collections import Counter,defaultdict
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
GEOM=OUT.parent/'geometry/frames'
def load(p): return json.loads(p.read_bytes())
def save(p,x): p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
if __name__=='__main__':
    rows=[]; totals=defaultdict(Counter)
    for p in sorted([*(OUT/'cases').glob('*.json'),*(OUT/'native12/cases').glob('*.json')]):
        mat=load(p); key=mat['key']; group=mat['cohort']
        if group in ('regression','development'): group='fixed56'
        if group in ('twinspire','cloister'): group='additional24'
        geo=load(GEOM/key/'registered.json')
        assert key==geo['key']
        placed=set(map(tuple,geo['registered']))
        visible={tuple(r[:3]):r[3] for r in geo['visible_states']}
        known={tuple(f['xyz']):f['guess'] for f in mat['faces'] if f.get('aligned') and f['expected']==f['guess']}
        assert all(visible.get(x)==y for x,y in known.items()),key
        match=set(known)&placed
        smooth={x for x,b in visible.items() if b=='minecraft:smooth_stone'}
        direct=placed&smooth
        score=dict(visible_truth=len(visible),named_exact_distinct_blocks=len(known),coords_correct=len(placed&visible.keys()),coords_extra=len(placed-visible.keys()),
                   correct_coordinate_and_named_face_overlap=len(match),of_overlap_already_smooth=sum(x in smooth for x in match),exported_coord_and_state=len(direct),
                   oracle_wired_including_smooth=len(direct|match))
        rows.append(dict(key=key,group=group,**score))
        for g in (group,'all'): totals[g].update(score)
    assert len(rows)==92
    result=dict(rule='Per frame, intersect only correctly located and named face XYZ keys (one per block) with actual decoded output after the scoring-only registration. Covers association of existing verified names to existing correct coordinates. Uses truth and is an upper bound for wiring this subset. Smooth-stone matches use actual exported ID; they need no material head.',results=dict(totals),frames=rows)
    save(OUT/'coordinate-material-join.json',result)
    print(dict(totals))

