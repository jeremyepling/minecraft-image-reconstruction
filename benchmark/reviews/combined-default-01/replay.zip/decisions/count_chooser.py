"""Join frozen candidate outputs to the promoted counter per image/proposal, then inspect answer-assisted ceilings."""
from collections import Counter
import hashlib,json
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
BASE=ROOT/'benchmark/reviews'
sources={}
def load(folder):
    p=BASE/folder/'cases.json'
    manifest=json.loads(p.with_name('manifest.json').read_bytes())
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    assert manifest['artifacts']['cases.json']==h
    sources[folder]=h
    rows=json.loads(p.read_bytes())
    assert len({r['key'] for r in rows})==len(rows)
    return {r['key']:r for r in rows}
fixed=load('count-transfer-comparison-01')
rect=load('texture-photo-count-01')
family=load('count-transfer-check-01')
patch=load('within-wall-grid-01')
verified={r['key']:r for r in json.loads((BASE/'texture-guided-default-01/suite.json').read_bytes())['frames']}
assert len(patch)==len(verified)==80 and patch.keys()==verified.keys()==fixed.keys()|family.keys()
accepted=[]
candidates=[]
stats={}
def st(v,truth):
    return 'unknown' if None in v else ('unmatched' if truth is None else ('exact' if v==truth else 'wrong'))
for key,frame in patch.items():
    f= (fixed|family)[key]
    assert frame['sha256']==f['sha256']==verified[key]['sha256']
    if key in fixed: assert rect[key]['sha256']==f['sha256']
    source={s['proposal']:s for s in f['surfaces']}
    rects={s['proposal']:s for s in rect[key]['surfaces']} if key in fixed else source
    tally=Counter()
    for s in frame['surfaces']:
        name=s['proposal']
        old=source[name]; ref=rects[name]; truth=s.get('actual')
        assert old.get('actual')==ref.get('actual')==truth and old.get('reference')==ref.get('reference')==s.get('reference')
        g=old['guess']; base=s['guess']['current']
        assert g.get('self_repeat',g.get('phase_repeat'))==base
        out={'default':base,'pre_fallback':g['current'],'refit':ref['guess']['rectify' if key in fixed else 'refit'],'patch':s['guess']['patch'],'coplanar':g['coplanar'],'atlas_confirm':g['phase']}
        if key in fixed:
            out.update(texture_repeat=ref['guess']['repeat'],texture_repeat_atlas=ref['guess']['atlas'])
        status={m:st(x,truth) for m,x in out.items()}
        detail=dict(key=key,layout=frame['layout'],cohort=f['cohort'] if key in fixed else f['family'],sha256=f['sha256'],proposal=name,actual=truth,guess=out,status=status)
        candidates.append(detail)
        if None in g['current'] and None not in base:accepted.append(detail)
        tally[status['default']]+=1
    for category,verified_key in [('exact','correct'),('wrong','incorrect'),('unmatched','unmatched_returned')]:assert tally[category]==verified[key][verified_key]
assert len(candidates)==1067
def summarize(rows):
    common=['pre_fallback','refit','patch','coplanar','atlas_confirm']
    extras=['texture_repeat','texture_repeat_atlas']
    def gain(r,group):
        return r['status']['default']!='exact' and any(r['status'].get(m)=='exact' for m in group)
    def compare(m):
        return dict(gained=sum(gain(r,[m]) for r in rows),lost=sum(r['status']['default']=='exact' and r['status'].get(m)!='exact' for r in rows if m in r['status']),contributed_unique=sum(gain(r,[m]) and not gain(r,[k for k in common if m!=k]) for r in rows))
    return dict(proposals=len(rows),current=dict(Counter(r['status']['default'] for r in rows)),
        accepted_fallback=dict(Counter(r['status']['default'] for r in rows if None in r['guess']['pre_fallback'] and None not in r['guess']['default'])),
        oracle_added_exact=sum(gain(r,common) for r in rows),
        extra_baseline_texture_methods_only_tested_on_fixed56=sum(gain(r,extras) and not gain(r,common) for r in rows),
        methods={m:compare(m) for m in common})
for cohort in sorted({'all','fixed56','additional24',*(r['cohort'] for r in candidates)}):
    selected=[r for r in candidates if cohort=='all' or cohort==r['cohort'] or cohort=='fixed56' and r['key'] in fixed or cohort=='additional24' and r['key'] in family]
    stats[cohort]=summarize(selected)
out=dict(revision='7c2137c',version='26.3',source_cases_sha256=sources,frame_sha_and_surface_reference_and_promoted_per_frame_scores_verified=True,method='Answers used only to inspect run outputs, eligible true surface widths and heights are exact ordered pairs. Unknown on unmatched proposals is unscored. No world placements are inferred from this count oracle.',scores=stats)
(OUT/'count-chooser.json').write_text(json.dumps(out,indent=2)+'\n')
(OUT/'count-chooser-cases.json').write_text(json.dumps(candidates,indent=2)+'\n')
print(json.dumps(stats,indent=2))
