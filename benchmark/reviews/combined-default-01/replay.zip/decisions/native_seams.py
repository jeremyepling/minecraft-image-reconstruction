"""Check the two frozen offset-only fallback methods on the camera-selected native suite."""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from unittest.mock import patch
import json
import sys
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent/'material'))
import native12 as native
from benchmark import boundary_block_seam,learned_block_seam
from engine import atlas_phase
from benchmark.camera_round import read,save,digest
def one(job):
    row,mask_hash,method=job
    original=atlas_phase.register_phase
    module={'boundary':boundary_block_seam,'learned':learned_block_seam}[method]
    def fallback(sample,result,atlas):
        base=original(sample,result,atlas)
        if any(v is None for v in base['counts']) or None not in base['phase']:return base
        return dict(base,phase=module.predict(sample,base)['phase'])
    with patch.object(atlas_phase,'register_phase',fallback):
        new=native.one((row,mask_hash))
    base=read(native.OUT/'cases'/(new['key']+'.json'))
    assert base['sha256']==new['sha256'] and base['source_predictions_sha256']==new['source_predictions_sha256'] and new['surfaces_both_counts']==base['surfaces_both_counts']
    return dict(key=new['key'],sha256=new['sha256'],method=method,scores=new['score'],default=base['score'])
if __name__=='__main__':
    manifest=read(native.MASKS/'manifest.json')
    jobs=[]
    for row in read(native.SOURCES)['results']:
        k=row['id']; assert manifest[k]['rgb']==row['rgb_sha256']
        for method in ['boundary','learned']:jobs.append((row,manifest[k]['masks'],method))
    with ProcessPoolExecutor(max_workers=4,initializer=native.m.init) as p: rows=list(p.map(one,jobs))
    counters={}
    for method in ['boundary','learned']:
        c=Counter()
        for r in rows:
            if method==r['method']:c.update(r['scores'])
        counters[method]=dict(c)
    save(OUT/'native-seams.json',dict(revision='7c2137c',source_manifest_sha256=digest(native.OUT/'manifest.json'),scores=counters,frames=rows))
    print(counters)

