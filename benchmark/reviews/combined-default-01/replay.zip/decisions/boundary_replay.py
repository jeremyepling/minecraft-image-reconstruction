"""Replay the frozen boundary-origin rule after the shipped atlas step, with production material matching."""
from pathlib import Path
import io, json, sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from tempfile import TemporaryDirectory
from unittest.mock import patch
from zipfile import ZipFile
from PIL import Image
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
sys.path.insert(0,str(ROOT))
import benchmark
OLD=ROOT.parent/'minecraft-image-reconstruction-worktrees'/'atlas-phase-materials'
benchmark.__path__.append(str(OLD/'benchmark'))
from benchmark.boundary_block_seam import predict as boundary
from benchmark.camera_round import read, save, digest
from benchmark.normal_round import groups
from benchmark.count_metrics import reference_planes
from benchmark.count_materials import true_faces
from benchmark.surface_reference import ARCHIVE,recorded
from benchmark.surface_metrics import truth
from benchmark.mask_metrics import measure
from benchmark.detail_transfer import ARCHIVE as FAMILY, member,shards
from benchmark.phase_material_round import link,grade
from benchmark.wall_join_test import checked,read_gzip
from engine import texture_guided_count, atlas_phase, photo_edges
from engine.surface_model import _count_regions,_material_assets
from runtime.mode import mark_image_only
REF=ROOT/'benchmark/reviews/edge-detail-stable-01'
METHOD='edge_detail:native4-stable-counts'
from contextlib import nullcontext
def init():
    global atlas,matcher
    mark_image_only()
    atlas,matcher,_,_=_material_assets('26.3','texture-guided-repeat','shape',None)
    assert atlas is not None and matcher is not None
def one(job):
    key,cohort,sha,c,r,pred_hash=job
    if r.get('id'):
        with ZipFile(c) as source:
            image=Image.open(io.BytesIO(member(source,r,'rgb.png'))).convert('RGB')
        frozen=read_gzip(checked(FAMILY/'ordinary'/(key+'.json.gz'),pred_hash))
        assert frozen['manifest']['image_sha256']==sha
        parts,_=photo_edges.refine_surfaces(image,frozen['planes'])
    else:
        with Image.open(checked(c.path('image'),sha)) as src: image=src.convert('RGB')
        parts=read_gzip(checked(REF/r['predictions'],pred_hash))[METHOD]
    cache={}
    def count_cached(image,plane,sample,version):
        name=plane['id']
        if name not in cache: cache[name]=original_count(image,plane,sample,version=version)
        return cache[name]
    original_count=texture_guided_count.count_surface
    original_register=atlas_phase.register_phase
    def fallback(sample,result,atlas):
        base=original_register(sample,result,atlas)
        if any(v is None for v in base['counts']) or None not in base['phase']: return base
        return dict(base,phase=boundary(sample,base)['phase'])
    pred={}
    surfaces={}
    with patch.object(texture_guided_count,'count_surface',count_cached):
        for arm in ('default','boundary'):
            with patch.object(atlas_phase,'register_phase',fallback) if arm=='boundary' else nullcontext():
                with TemporaryDirectory(dir=OUT) as directory:
                    report=_count_regions(image,parts,'26.3','texture-guided-repeat',atlas,Path(directory),matcher)
            assert report['atlas_phase']['surface_errors']==0
            surfaces[arm]={p['id']:p for p in report['surfaces']}
            pred[arm]=sorted([dict(f,proposal=p['id'],block_id=(f.get('material') or {}).get('block_id')) for p in report['surfaces'] for f in p.get('visible_cells',[])+p.get('under_five_px_faces',[])],key=lambda f:f['face_index'])
    if r.get('id'):
        with ZipFile(c) as source:
            faces=json.loads(member(source,r,'reference-faces.json'))['faces']
            ref=truth(json.loads(member(source,r,'camera.json')),faces)
    else:
        ref=recorded(c)[1]; faces=read(c.path('labels'))['faces']
    valid=true_faces(reference_planes(ref,faces),image.size)
    paired={parts[i]['id']:rid for i,rid in measure(parts,ref,use_mask=True)[1]}
    scores={}; exact={}; added=[]
    for arm,rows in pred.items():
        scores[arm],records=grade(rows,link(rows,paired,valid,ref),valid)
        exact[arm]={(tuple(f['xyz']),f['direction'],f['guess']) for f in records if f.get('aligned') and f['guess']==f['expected']}
    for name,a in surfaces['default'].items():
        b=surfaces['boundary'][name]
        assert a['counts']==b['counts'] and a['dimensions']==b['dimensions'] and a.get('quad')==b.get('quad')
        if a['phase']!=b['phase']:
            assert all(x is None or x==y for x,y in zip(a['phase'],b['phase']))
            added.append(dict(proposal=name,before=a['phase'],after=b['phase']))
    return dict(key=key,cohort=cohort,sha256=sha,scores=scores,new_origins=added,gained_exact=sorted(exact['boundary']-exact['default']),lost_exact=sorted(exact['default']-exact['boundary']))
if __name__=='__main__':
    src=read(checked(REF/'manifest.json','d8a2c401d28c546762bcef38ed731c4074120f3750f2998a5b7e797fcb6e9a43'))
    checked(ARCHIVE,src['reference_sha256'])
    caps,_,fixtures=groups()
    assert src['fixtures']==fixtures
    cap={c.floor+'/'+c.id:c for cc in caps.values() for c in cc}
    jobs=[(r['key'],r['cohort'],r['sha256'],cap[r['key']],r,src['artifacts'][r['predictions']]) for r in read(checked(REF/'cases.json',src['artifacts']['cases.json']))]
    fm=read(FAMILY/'manifest.json')
    for split,path,meta in shards(ROOT/'runs/visible-builds-v1'):
        with ZipFile(path) as source: frames=[json.loads(s) for s in source.read('frames.jsonl').splitlines()]
        for f in frames: jobs.append((f['id'],f['family'],f['image_sha256'],path,f,fm['artifacts']['ordinary/'+f['id']+'.json.gz']))
    with ProcessPoolExecutor(max_workers=5,initializer=init) as pool: rows=list(pool.map(one,jobs))
    summary={}
    for cohort in sorted({'all',*(r['cohort'] for r in rows)}):
        chosen=[r for r in rows if cohort in ('all',r['cohort'])]
        summary[cohort]=dict(frames=len(chosen),surfaces_gaining_offsets=sum(len(r['new_origins']) for r in chosen),gained_exact=sum(len(r['gained_exact']) for r in chosen),lost_exact=sum(len(r['lost_exact']) for r in chosen))
        for arm in ('default','boundary'):
            c=Counter()
            for r in chosen:c.update(r['scores'][arm])
            summary[cohort][arm]=dict(c)
    save(OUT/'boundary-compatibility-cases.json',rows)
    save(OUT/'boundary-compatibility.json',dict(default_revision='7c2137c',rule='require both measured spacings, apply original boundary phase to axes still unresolved after production atlas',boundary_source_sha256=digest(OLD/'benchmark/boundary_block_seam.py'),fixed_manifest_sha256=digest(REF/'manifest.json'),family_manifest_sha256=digest(FAMILY/'manifest.json'),fixtures=fixtures,visible_truth=src['reference_sha256'],scores=summary))
    print(summary)

