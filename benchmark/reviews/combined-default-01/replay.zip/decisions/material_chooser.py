"""Hold selected production quads fixed and score the existing four material matchers."""
import json,sys,io
from pathlib import Path
from collections import Counter
from zipfile import ZipFile
from PIL import Image
import numpy as np
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
sys.path.insert(0,str(ROOT))
from benchmark.camera_round import read,save,digest
from benchmark.detail_transfer import member, shards, ARCHIVE as FAMILY
from benchmark.normal_round import groups
from benchmark.wall_join_test import checked,read_gzip
from engine.geometry import face
from engine.surface_tiles import tile_sample
from engine.atlas_count import rank_tile
from engine.block_exposure import ExposureMatcher
from engine.blocker_shadow import surface_shadow_map,cell_shadow,corrected
from engine.surface_model import _material_assets
from engine import photo_edges
from runtime.mode import mark_image_only
mark_image_only()
atlas,shape,path,_=_material_assets('26.3','texture-guided-repeat','shape',None)
library=path.parent/'face_textures/softened-library.npz'
exp=ExposureMatcher(path,library,catalog=atlas.material_index)
data=OUT.parent/'material'
fixed=ROOT/'benchmark/reviews/edge-detail-stable-01'
fm=read(fixed/'manifest.json')
rows={r['key']:r for r in read(checked(fixed/'cases.json',fm['artifacts']['cases.json']))}
family_frames={}
for split,p,_ in shards(ROOT/'runs/visible-builds-v1'):
    with ZipFile(p) as z:
        for line in z.read('frames.jsonl').splitlines():
            f=json.loads(line)
            family_frames[f['id']]=(p,f)
caps={c.floor+'/'+c.id:c for cc in groups()[0].values() for c in cc}
records=[]; cohort_frames=Counter()
for p in sorted((data/'cases').glob('*.json')):
    case=read(p);key=case['key'];cohort=case['cohort'];cohort_frames[cohort]+=1
    if not case['faces']:continue
    if key in caps:
        assert case['sha256']==rows[key]['sha256']
        with Image.open(checked(caps[key].path('image'),case['sha256'])) as im:image=im.convert('RGB')
        pred=rows[key]['predictions']
        parts=read_gzip(checked(fixed/pred,case['source_predictions_sha256']))['edge_detail:native4-stable-counts']
    else:
        shard,f=family_frames[key]
        assert f['image_sha256']==case['sha256']
        with ZipFile(shard) as z:image=Image.open(io.BytesIO(member(z,f,'rgb.png'))).convert('RGB')
        inputs=read_gzip(checked(FAMILY/'ordinary'/(key+'.json.gz'),case['source_predictions_sha256']))
        parts,_=photo_edges.refine_surfaces(image,inputs['planes'])
    rgb=np.asarray(image)
    shadow=surface_shadow_map(rgb,[p for p in parts if p.get('support')])
    result={}
    for idx in {r['source_face'] for r in case['faces']}:
        assert idx is not None
        q=case['faces'][idx]['quad']
        tile=tile_sample(image,q); patch=tile['rgb']
        gains,_=cell_shadow(shadow,tile['quad'],len(patch))
        result[idx]=dict(shape='minecraft:'+shape.rank_patch(patch)['block_id'],
                         shape_shadow='minecraft:'+shape.rank_patch(corrected(patch,gains))['block_id'],
                         atlas=rank_tile(tile,atlas)['block_id'],
                         exposure='minecraft:'+exp.rank_patch(face(rgb,tile['quad'],16))['block_id'])
    for r in case['faces']:
        preds=result[r['source_face']]
        assert preds['shape']==r['guess']
        records.append(dict(key=key,cohort=cohort,reference=r.get('reference'),aligned=r.get('aligned',False),expected=r.get('expected'),preds=preds))
stats={}
for co in [*cohort_frames.keys(),'all']:
    sub=[r for r in records if co in ('all',r['cohort'])]
    match=[r for r in sub if r['aligned']]
    st=dict(guesses=len(sub),aligned=len(match),unverified=len(sub)-len(match))
    for method in ('shape','shape_shadow','atlas','exposure'):
        st[method]=sum(r['preds'][method]==r['expected'] for r in match)
    st['perfect_top1_picker']=sum(r['expected'] in r['preds'].values() for r in match)
    stats[co]=st
save(OUT/'material-method-chooser.json',dict(revision='7c2137c',atlas_sha256=atlas.provenance['atlas_sha256'],library_sha256=digest(library),material_manifest_sha256=digest(data/'manifest.json'),scores=stats,cases=records))
print(stats)

