place template reconstruction:part_0 ~-19 ~0 ~3
place template reconstruction:part_1 ~0 ~0 ~3
