"""Assign vanilla block IDs to the final, first-hit visible placements."""
from collections import Counter

import numpy as np

from engine.projected_appearance import Scene
from engine.thin_atlas_faces import _corr, _mips

FALLBACK = 'smooth_stone'
METHODS = ('face', 'palette', 'auto')


class Catalog:
    def __init__(self, atlas):
        self.means = atlas.means
        self.norm = np.maximum(1, (atlas.means ** 2).sum(1))
        quantiles = np.percentile(atlas.tiles.reshape(-1, 256, 3), (15, 50, 85), axis=1)
        self.medians = quantiles[1].astype(np.float32)
        self.spread = ((quantiles[2] - quantiles[0]) * .5).astype(np.float32)
        self.maps = _mips(atlas)
        self.blocks = sorted({name.removeprefix('minecraft:') for ids in atlas.ids for name in ids})
        index = {name: i for i, name in enumerate(self.blocks)}
        self.sprites, self.candidates, self.tie = [], [], []
        for texture, choices in enumerate(atlas.ids):
            for order, name in enumerate(choices):
                self.sprites.append(texture)
                self.candidates.append(index[name.removeprefix('minecraft:')])
                self.tie.append(.04 * min(order, 10))
        self.sprites = np.asarray(self.sprites)
        self.candidates = np.asarray(self.candidates)
        self.tie = np.asarray(self.tie)

    def face(self, pixels, uv, normal_gain):
        # Interior texels tolerate small camera and outline errors at boundaries.
        inner = (uv % 16 >= 2) & (uv % 16 < 14) & (uv // 16 >= 2) & (uv // 16 < 14)
        if inner.sum() >= max(5, len(uv) // 4):
            pixels, uv = pixels[inner], uv[inner]
        if len(uv) > 256:
            chosen = np.linspace(0, len(uv)-1, 256, dtype=int)
            pixels, uv = pixels[chosen], uv[chosen]
        # Vanilla daylight has a slight blue cast in these source captures.
        pixels = pixels / np.array([.99, 1., 1.021], dtype=np.float32)
        q = np.percentile(pixels, (15, 50, 85), axis=0)
        median, spread = q[1], .5 * (q[2] - q[0])
        gain = np.clip((self.medians * median).sum(1) / np.maximum(1, (self.medians**2).sum(1)),
                       .26, 1.08)
        residual = np.abs(self.medians * gain[:, None] - median).mean(1)
        # Shadows are common underneath rims. Cap their directional penalty.
        shade = abs(np.log(gain / normal_gain))
        contrast = np.abs(np.log((self.spread * gain[:, None] + 1.6)/(spread+1.6))).mean(1)
        loss = residual * 1.7 + 4.0 * contrast + 8.0 * shade
        if len(uv) >= 8 and np.std(pixels.mean(1)) > .5:
            short = np.argsort(loss, kind='stable')[:16]
            occupied, group, counts = np.unique(uv, return_inverse=True, return_counts=True)
            if len(occupied) >= 8:
                gray = (np.bincount(group, weights=pixels.mean(1)) / counts).astype(np.float32)
                corr = _corr(self.maps[short][..., occupied], gray).max(axis=(1, 2))
                strength = min(1., (len(occupied)-4)/32)
                loss[short] -= 13 * strength * np.maximum(0., corr-.30)
        block_loss = np.full(len(self.blocks), 1000., dtype=np.float32)
        np.minimum.at(block_loss, self.candidates, loss[self.sprites] + self.tie)
        return block_loss


def _fallback(cells):
    return {c:FALLBACK for c in cells}, {c:'fallback' for c in cells}


def assign_many(image, camera, cells, atlas, *, methods=METHODS):
    """Compare matchers on identical cubes, pixels and camera without repeated rasterization."""
    if not set(methods).issubset(METHODS):
        raise ValueError(f'Unknown placement material method in {methods}')
    cells = sorted({tuple(map(int, c)) for c in cells})
    if not cells or atlas is None or camera is None or camera.get('P') is None:
        return {m:_fallback(cells) for m in methods}
    matrix = np.asarray(camera['P'], dtype=float)
    if matrix.shape != (3,4) or not np.isfinite(matrix).all() or np.linalg.matrix_rank(matrix[:,:3]) < 3:
        return {m:_fallback(cells) for m in methods}
    scene = Scene(image.convert('RGB'), [], camera, cells)
    catalog = getattr(atlas, '_placed_catalog', None)
    if catalog is None:
        catalog = atlas._placed_catalog = Catalog(atlas)
    rgb = scene.rgb.reshape(-1,3).astype(np.float32)
    observed = []
    losses = []
    for number, indices in scene.owned.items():
        cell = cells[number]
        faces, weights = [], []
        for axis in np.unique(scene.axes[indices]):
            idx = indices[scene.axes[indices] == axis]
            if len(idx) < 2:
                continue
            direction = (1. if scene.eye[1] > cell[1]+1 else .5) if axis == 1 else (.60 if axis == 0 else .80)
            faces.append(catalog.face(rgb[idx], scene.uv(idx, cell, axis), direction))
            weights.append(min(24., len(idx)**.65))
        if faces:
            losses.append(np.average(faces, axis=0, weights=weights))
            observed.append(cell)
    if not observed:
        return {m:_fallback(cells) for m in methods}
    loss = np.array(losses)
    first = np.argmin(loss, axis=1)
    # A source image supplies its own palette. Shrink uncertain guesses toward
    # IDs independently supported on other cubes, while preserving distinct accents.
    counts = np.bincount(first, minlength=len(catalog.blocks))
    prior = np.log1p(counts)
    adjusted = loss - 2.5 * prior
    selections = {'face':first, 'palette':adjusted.argmin(1)}
    winners = adjusted.argmin(1)
    refined = loss - 3.2 * np.log1p(np.bincount(winners, minlength=len(prior)))
    selections['auto'] = refined.argmin(1)
    result = {}
    for method in methods:
        ids, evidence = _fallback(cells)
        for cell, choice in zip(observed, selections[method]):
            ids[cell] = catalog.blocks[choice]
            evidence[cell] = 'source-atlas'
        result[method] = ids, evidence
    return result


def assign(image, camera, cells, atlas, *, method='auto'):
    """Return bare Minecraft IDs and evidence status, each keyed by local xyz."""
    return assign_many(image, camera, cells, atlas, methods=(method,))[method]

